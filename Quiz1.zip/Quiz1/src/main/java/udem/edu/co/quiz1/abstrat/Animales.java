/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package udem.edu.co.quiz1.abstrat;

/**
 *
 * @author petr_0510
 */
public abstract class Animales  {
    private String reino;
    private String nombre;
    private String color;
    private int vida;

    public Animales(String reino, String nombre, String color, int vida) {
        this.reino = reino;
        this.nombre = nombre;
        this.color = color;
        this.vida = vida;
    }

    public String getReino() {
        return reino;
    }

    public void setReino(String reino) {
        this.reino = reino;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }
    
    
        
    }     
    

