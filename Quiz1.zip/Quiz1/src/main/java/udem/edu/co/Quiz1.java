/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package udem.edu.co;

import java.util.ArrayList;
import java.util.List;
import udem.edu.co.quiz1.Brocoli;
import udem.edu.co.quiz1.Cilantro;
import udem.edu.co.quiz1.Perro;
import udem.edu.co.quiz1.interfaces.Clasificacion;

/**
 *
 * @author petr_0510
 */
public class Quiz1 {

    public static void main(String[] args) {
        List<Clasificacion> lista = new ArrayList<>();
        
        lista.add(new Cilantro("",""));
        lista.add(new Brocoli());
        lista.add(new Perro(, 1));
        lista.add(new Perro( 2));

        for (Clasificacion) {

            System.out.println(Clasificacion.toString());
        }
    }
}

