/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package udem.edu.co.quiz1.interfaces;

/**
 *
 * @author petr_0510
 */
public interface Clasificacion {
    
    /*
    Metodos que permiten saber el color y tiempo de vida pedidos.
    */
    public String color();
    public int vida();
}
