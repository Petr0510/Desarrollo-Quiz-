/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package udem.edu.co.quiz1;

import udem.edu.co.quiz1.abstrat.Animales;
import udem.edu.co.quiz1.interfaces.Clasificacion;

/**
 *
 * @author petr_0510
 */
public class Perro extends Animales  {

    private String color;
    private String nombre;
    private String reino;
    private int vida;

    public Perro(String color, String nombre, String reino, int vida) {
        super(reino, nombre, color, vida);
        this.color = color;
        this.nombre = nombre;
        this.reino = reino;
        this.vida = vida;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getReino() {
        return reino;
    }

    public void setReino(String reino) {
        this.reino = reino;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }
    
    
  


    
    
    
        public String toString() {
        String aux = "{\"Perro\":\n"  
                + "        \"Nombre\":\n"
                + "        \""+super.getNombre()+"\",\n"
                + "        \"Reino\":\n"
                + "        \""+super.getReino()+"\",\n"
                + "        \"Color\":\n"
                + "        \""+super.getColor()+"\",\n" 
                + "        \"Vida\":\n"
                + "        \""+super.getVida()+"\",\n"      
                + "    }\n"
                + "}";
        return aux;
        
    }     

   
    
    
}

